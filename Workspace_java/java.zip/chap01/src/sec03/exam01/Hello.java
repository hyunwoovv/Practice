package sec03.exam01;

public class Hello {
/*범위 주석*/
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//한줄주석
		
		//한 줄 지우기 : Ctrl + d
		//한 줄 복사 : Ctrl + Alt + 방향키
		//한 줄 이동 : Alt + 방향키
		//코드 정렬 : Ctrl + Shift + f
		
	System.out.println("Hello World"); 	
	}

}
