package sec01.exam01;

public class DanExam {

	public static void main(String[] args) {

//		for (int d = 2; d <= 9; d++) {
//			for (int e = 1; e <= 9; e++) {
//				System.out.print(d + "*" + e + " = " + (d * e) + "  ");
//			}
//System.out.println();
//		}
	for (int d = 1; d <=9; d++) {
		for (int e = 2; e <= 9; e++) {
			System.out.print(e + "*" + d + " = " + (d * e) + "  ");
		}
System.out.println();
	}

}
}