package chap05;

public enum LoginResult {

	SUCCESS, FAIL
	
}
