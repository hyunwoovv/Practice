package sec01.exam01;

import java.util.Scanner;

public class practice {

	public static void main(String[] args) {
	
	boolean car;
	car=true;
	
	int phone;
	phone=4;
	
	String name="남현우";
	
	double area = 3.3 * 5;

	int a =2000000000;
	int b =2000000000;
	
	long c = (long)a+b;
	System.out.println(c);
	
	Scanner scanner = new Scanner(System.in);
	}

}
